import settings.Configure;

public class Compiler {
    public static void main(String[] args) {
        Configure.run();
    }
}
