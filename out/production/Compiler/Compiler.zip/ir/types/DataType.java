package ir.types;

public abstract class DataType extends Type{
    public DataType(TypeID typeID) { super(typeID); }
}
