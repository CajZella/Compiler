package backend.lir.mipsOperand;

import util.MyLinkedNode;

public abstract class MpOpd extends MyLinkedNode {
}
